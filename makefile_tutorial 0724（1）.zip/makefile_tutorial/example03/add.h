#ifndef ADDITION_H
#define ADDITION_H

float addition(float a, float b);
#endif/*ADDITION_H*/
