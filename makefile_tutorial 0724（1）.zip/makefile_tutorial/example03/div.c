float division(float a, float b)
{
    return (a/b);
}
