float multiplication(float a, float b)
{
    return (a*b);
}
