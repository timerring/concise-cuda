#ifndef MULTIPLICATION_H
#define MULTIPLICATION_H

float multiplication(float a, float b);
#endif/*MULTIPLICATION_H*/
